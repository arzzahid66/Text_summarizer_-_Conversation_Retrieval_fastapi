from fastapi import FastAPI, File, UploadFile, APIRouter, HTTPException
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse , HTMLResponse
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from pydantic import BaseModel
from io import BytesIO
from dotenv import load_dotenv
import tempfile
from operator import itemgetter
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai.chat_models import ChatOpenAI
import openai
from fastapi import status
from langchain_core.prompts import PromptTemplate
from langchain_openai import OpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
import time 
# from text_summariser import search_summary
import tiktoken
# Load environment variables
load_dotenv()
import os
# Initialize FastAPI app and router
app = FastAPI()
router = APIRouter()

# Define a Pydantic model for the text input
class TextInput(BaseModel):
    text: str

# @router.get("/Welcome")
# def index():
#     message = "Welcome to Rayo Assistive AI"
#     html_content = f"<html><body><h1>{message}</h1></body></html>"
#     return HTMLResponse(content=html_content)



api_key = os.getenv('OPENAI_API_KEY')
openai.api_key = api_key

# Function to read different file types
def read_pdf(file_path):
    file_loader = PyPDFLoader(file_path)
    documents = file_loader.load()
    text = "\n".join([doc.page_content for doc in documents])
    return text

def read_docx(file_path):
    file_loader = Docx2txtLoader(file_path)
    documents = file_loader.load()
    text = "\n".join([doc.page_content for doc in documents])
    return text

def read_txt(file_path):
    file_loader = TextLoader(file_path)
    documents = file_loader.load()
    text = "\n".join([doc.page_content for doc in documents])
    return text


def num_tokens_from_string(text, model_name):
    encoding = tiktoken.encoding_for_model(model_name)
    tokens = encoding.encode(text)
    return len(tokens)

# Main function for search_summary
def search_summary(text):
    len_tokens = num_tokens_from_string(text, 'gpt-3.5-turbo')
    if len_tokens > 16000:
        text = text[:15999]
    try:
        prompt = """You are text summarizer who is expert at performing Extreme TLDR generation for given text. 
        Extreme TLDR is a form of extreme summarization, which performs high source compression, removes stop words and
        summarizes the text whilst retaining meaning. The result is the shortest possible summary that retains all of 
        the original meaning and context of the text. 
        text for Extreme TLDR generation : {topic}
        Extreme TLDR : """

        # summarizer_prompt = ChatPromptTemplate.from_template(prompt)
        # summarizer_prompt.format(text=text)
        # api_key = os.getenv('OPENAI_API_KEY')
        start_time = time.time()
        openai.api_key = ""
        
        model = OpenAI(openai_api_key= openai.api_key)
        prompt = ChatPromptTemplate.from_template(prompt)
        output_parser = StrOutputParser()
        chain = prompt | model | output_parser
        res = chain.invoke({"topic": text})
        end_time = time.time() # End time
        
        response_time = end_time - start_time
        return res , response_time
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Upload file endpoint
@router.post("/Summarizer using LCEL Chain/")
async def upload_file(file: UploadFile = File(...)):
    try:
        # Create a temporary file to save the uploaded file
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_file.write(await file.read())
            temp_file_path = temp_file.name

        # Determine file extension and read the file
        file_extension = file.filename.split('.')[-1].lower()
        if file_extension not in ['pdf', 'docx', 'txt']:
            raise HTTPException(status_code=400, detail="Unsupported file type")
        
        def read_doc(file_path, file_type):
            if file_type == 'pdf':
                return read_pdf(file_path)
            elif file_type == 'docx':
                return read_docx(file_path)
            elif file_type == 'txt':
                return read_txt(file_path)
            else:
                raise ValueError("Unsupported file type")
            
        text = read_doc(temp_file_path, file_extension)

        final_summary = search_summary(text)

        os.remove(temp_file_path)
        
        return JSONResponse({"filename": file.filename, "content_type": file.content_type, "content": final_summary})
    except Exception as e:
        raise HTTPException(status.HTTP_200_OK,detail=str(e))
    




