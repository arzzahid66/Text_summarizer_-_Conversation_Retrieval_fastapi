
from typing import Union
from fastapi import FastAPI , Response , status
from pydantic import BaseModel
from fastapi.responses import JSONResponse
from fastapi.responses import Response
import uvicorn
from fastapi.params import Body
from typing import Optional
from random import randrange
# from simple_qa import*
from fastapi import FastAPI, HTTPException
from routers import summarizer_using_lcel , qa_coversation
app = FastAPI()



app.include_router(summarizer_using_lcel.router,
                   prefix="/upload_file",
                   tags=["Lcel chain"])

app.include_router(qa_coversation.router,
                   prefix="/upload_file",
                   tags=["Conversation Retrieval"])


if __name__== "__main__":
    uvicorn.run("main:app",host="127.0.0.1",port=8000)

